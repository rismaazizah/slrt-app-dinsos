<?php 
        $mail->AltBody = "KANTOR KELURAHAN RANGDA MALINGKUNG"; //body email (optional)
 
	if(!$mail->send()) 
	{
	    echo "Mailer Error: " . $mail->ErrorInfo;
	} 
	else 
	{
	    echo "Message has been sent successfully";
	}
 ?>