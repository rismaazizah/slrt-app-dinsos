<?php
session_start();
$sql = mysqli_query($koneksi,"SELECT * FROM penduduk WHERE id_penduduk='$id_penduduk'");
$data = mysqli_fetch_array($sql);
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require_once "../../mail/library/PHPMailer.php";
require_once "../../mail/library/Exception.php";
require_once "../../mail/library/OAuth.php";
require_once "../../mail/library/POP3.php";
require_once "../../mail/library/SMTP.php";
 
	$mail = new PHPMailer;
    
	//Enable SMTP debugging. 
	$mail->SMTPDebug = 3;                               
	//Set PHPMailer to use SMTP.
	$mail->isSMTP();            
	//Set SMTP host name                          
	$mail->Host = "dahlia.ardetamedia.net"; //host mail server
	//Set this to true if SMTP host requires authentication to send email
	$mail->SMTPAuth = true;                          
	//Provide username and password               
    $ggmail = "rizkiaswandi@begaduhstartup.com";     
	$mail->Username = $ggmail;   //nama-email smtp          
	$mail->Password = "rizkiaswandi123";           //password email smtp
	//If SMTP requires TLS encryption then set it
	$mail->SMTPSecure = "ssl";                           
	//Set TCP port to connect to 
	$mail->Port = 465;                    
	$mail->From = $ggmail; //email pengirim
	$mail->FromName = "ADMIN KANTOR KELURAHAN RANGDA MALINGKUNG"; //nama pengirim
	$mail->addAddress("ikyaswandiofficial@gmail.com", "Admin Kantor Kelurahan Rangda Malingkung"); //email penerima
	$mail->isHTML(true);
	
 ?>